package arrayObjetos;

public class ListaAlunos {
	private Aluno[] alunos; // array objetos
	private int i = 0; // vari�vel de controle do �ndice
	
	//m�todo construtor
	public ListaAlunos(int qtde){
		//instanciando o array alunos
		alunos = new Aluno[qtde];
	}
	
	//insere um aluno na lista "alunos"
	public void insereAluno(Aluno a){
		if (i < alunos.length){
		alunos[i] = a;
		i++;
		}else{
			System.out.println("Lista cheia");
		}
	}
	
	public void imprimeLista(){
		for(int i=0; i < alunos.length; i++){
			System.out.println(alunos[i].toString());
		}
	}
	
	
	
	
	
	
}
